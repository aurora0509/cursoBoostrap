package com.example.tarea2activity;

import android.view.MenuItem;

interface MainActivity2 {
    boolean onOptionsitemselectec(MenuItem item);
}
