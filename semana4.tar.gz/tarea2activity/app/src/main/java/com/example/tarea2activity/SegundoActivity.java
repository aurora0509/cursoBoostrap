package com.example.tarea2activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class SegundoActivity extends AppCompatActivity {

    private  RecyclerView recyclerViewMascota;
    private RecyclerViewAdaptador adaptadorMascota;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segundo);
        recyclerViewMascota=(RecyclerView)findViewById(R.id.recyclerMascota);
        recyclerViewMascota.setLayoutManager(new LinearLayoutManager(this));

        adaptadorMascota= new RecyclerViewAdaptador(obtenerMascotas()) {
            @Override
            public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

            }
        };
        recyclerViewMascota.setAdapter(adaptadorMascota);
    }
    public List<MascotaModelo> obtenerMascotas(){
        List<MascotaModelo> mascota=new ArrayList<>();
        mascota.add(new MascotaModelo("chiquis","shiba inu",R.drawable.chiqui));
        return mascota;
    }

    //metodo para el boton anterior
    public void Anterior(View view){
        Intent anterior = new Intent(this, MainActivity.class);
        startActivity(anterior);

    }

}
